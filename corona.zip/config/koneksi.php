<?php 

	$con = mysqli_connect("localhost","id12706387_adamcahyo","Adam-Cahyo123","id12706387_db_corona");
 ?>